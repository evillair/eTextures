9/7/01

Name: evil lair's Quake 3:Arena texture set 7  
Short Name: e7
Author: Yves Allaire aka "evil lair"
Email: yves@evillair.net
URL: http://evillair.net

[Description]
Quake 3: Arena texture set in a gothic/metal theme.

[instructions for Q3Radient/GTKRadient users]

basic usage:
Place the 'e7' folder inside your "baseq3/textures' folder
Place the e7.shader in your /scripts folder
Add e7 to your shaderlist.txt file to see them in Q3Radient/GTKRadient

suggested usage:
I'd encourage you to make your own directories for my textures for your map like so ... 

"baseq3/textures/mymapname/" (place my textures here.)

"baseq3/scripts/mymapname.shader" (add my shaders here, making sure to edit the paths in the original shader file.)

[Thanks]
Everyone who had kind words to say about my other sets and
the people at the Quake3World.com Level Editing Forum.

Everyone who has used/will use my textures in their maps.
This is why I make them. :)


[Stuff]
If you use any of the textures it would be cool if you emailed me with the url to some screenshots if possible. 
I really would like to see what uses mappers have made of them.

[Copyright/Permissions]
-You may use these texture in your maps/mods/tc�s as long as you give me credit.
-You may not edit, modify any textures within this archive unless given permission to do so by the author.  
-You may convert these textures to other game formats but only with the author�s permission (me).


QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks
of id Software, Inc.




[:Made With A Mac:]
