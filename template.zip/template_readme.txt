12/14/2003


Name: evil lair's Template textures  
Short Name: temp
Author: Yves Allaire aka "evil lair"
Email: yves@evillair.net
URL: http://evillair.net

[Description]
Quake 3: Arena texture template textures.

[instructions for Q3Radient/GTKRadient users]

basic usage:
Place the 'template' folder inside your "baseq3/textures' folder
Add template to your shaderlist.txt file to see them in Q3Radient/GTKRadient


[Copyright/Permissions]
-You may not edit, modify any textures within this archive unless given permission to do so by the author.  

QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks
of id Software, Inc.
