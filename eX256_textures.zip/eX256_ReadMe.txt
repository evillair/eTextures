11/20/2005 

Name: evillair's Quake4 eX Texture Set v256
Short Name: eX256
Author: Yves Allaire aka "evillair"
Email: admin@evillair.net
URL: http://evillair.net

=============================================================================================

[Description]
Simple Quake 4 texture set in a tech base style. This is the scaled down 256 version.

=============================================================================================
[Instructions]

Extract the .zip file into your "q4base" folder.

>> Suggested usage:
>> I'd encourage you to make your own directories for my textures for your map like so ... 

>> "q4base/textures/mymapname/" (place my textures under "mymapname".)

>> "q4base/materials/mymapname.mtr" Add my mtr file here. Making sure to edit the paths in the original shader file. (Find\Replace "/eX256/" to "/yourmapname/" (no quotes)))

=============================================================================================

[Thanks]
Everyone who had kind words to say about my other sets.

Everyone who has used/will use my textures in their maps.
This is why I make them. :)

=============================================================================================

[Copyright/Permissions]
-You may edit the material file (.mtr file) as you see fit.
-You may change the color of any "texturename.blend.tga" or hue to fit the style of your map.
-You may use these texture in your maps/mods/tc's as long as you give me credit.
-You may not edit, modify any textures within this archive unless given permission to do so by the author unless specified above.  
-You may convert these textures to other game formats but only with the author's permission (me).


QUAKE, QUAKE II and QUAKE3:ARENA and Quake 4 are registered trademarks
of id Software, Inc & Raven Software.

=============================================================================================
Enjoy! and thanks again...
=============================================================================================