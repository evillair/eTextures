Monday, December 04, 2000

Name: Texture set: e6
Author: Yves Allaire aka evil lair
Email: yves@evillair.net
URL: http://evillair.net

[Description]
Quake 3: Arena texture set in a sci-fi industrial space station
theme.  

[Usage]
The shader files are seperated so you can easily edit them and
copy/past them into your own shader file for release of your maps.

[Thanks]
Maj (http://maj.gamedesign.net/) for helping me with the .shader
files. You the man! :)
Bal (http://www.planetquake.com/bal) for the help on how quake3
specific textures are used, since I cannot test them in a map editor.
(Maybe when they make a Mac Q3 editor!! ;)
Everyone who had kind words to say about my other texture sets and
the folks at the Quake3World.com Level Editing Forum.
Everyone who has used/will use my textures in their maps. This is why
I make them. :)

[Stuff]
Sorry for the lack of CTF textures, I just didn't have enought time
to make a decent set of them. And the ones I did make didn't turn out
too good. :\ Maybe next time.

If you use any of the textures please email me with the url to some
screenshots if possible. I really would like to see what uses mappers
have made of them.

[Copyright/Permissions]
-You may not edit, modify any textures within this archive unless
given permission to do so by the author.  
-You may not use these textures as base for your own.
-You may convert these textures to other game formats but only with
the author's permission.
-You may rename the textures.
-You may use these texture in your maps/mods/tc's as long as you give
me credit.
-I encourage you to edit the .shader to suit your needs.







QUAKE, QUAKE II and QUAKE3:ARENA are registered trademarks of id
Software, Inc.
